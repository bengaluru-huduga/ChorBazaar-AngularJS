export class Product {
    id:number = 0;
    name:string = '';
    brand:string = '';
    model:string = '';
    price:number = 0;
    madeIn:string = '';
    discount:number = 0;
    color:string = '';
    image:string = '';
}
