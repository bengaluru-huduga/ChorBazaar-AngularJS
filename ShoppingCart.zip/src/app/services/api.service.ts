import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { map } from 'rxjs'

@Injectable({
    providedIn: 'root'
})
export class ApiService {

    cartArray: any = [];

    constructor(private httpClient: HttpClient) {

    }

    // ngOnInit() {
    //     this.getAllCartProducts();
    // }

    getAllProducts() {
        return this.httpClient.get<any>("http://localhost:3000/posts").pipe(
            map((response: any) => {
                return response;
            })
        );
    }

    getAllCartProducts() {
        return this.cartArray;
    }
    // getAllCartProducts() {
    //     return this.httpClient.get<any>("http://localhost:3000/cart").pipe(
    //         map((response: any) => {
    //             return response;
    //         })
    //     );
    // }

    getProductById(id: any) {
        return this.httpClient.get<any>("http://localhost:3000/posts/" + id).pipe(
            map((response: any) => {
                return response;
            })
        );
    }

    saveProductToCart(data: any) {
        this.cartArray.push(data);
    }

    // deleteCartItem(productId: any){
    //     return this.httpClient.delete<any>("http://localhost:3000/cart/"+productId).pipe(
    //         map((response:any)=>{
    //             return response;
    //         })
    //     );
    // }

    deleteFromCart(data: any) {
        for (let i = 0; i < (this.cartArray).length; i++) {
            if ((this.cartArray[i]).id == data) {
                (this.cartArray).splice(i, 1);
                break;
            }
        }
    }

    deleteAllCartItems() {
        this.cartArray = [];
    }
    // deleteAllCartItems() {
    //     return this.httpClient.delete<any>("http://localhost:3000/cart").pipe(
    //         map((response: any) => {
    //             return response;
    //         })
    //     );
    // }
}
