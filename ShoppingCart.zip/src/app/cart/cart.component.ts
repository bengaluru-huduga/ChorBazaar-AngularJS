import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
    selector: 'app-cart',
    templateUrl: './cart.component.html',
    styleUrls: ['./cart.component.css']
})
export class CartComponent {

    productId: any;
    productArray: any = [];
    grandTotal : number = 0;

    constructor(private activatedRoute: ActivatedRoute, private api: ApiService, private router: Router) {

    }

    ngOnInit() {

        this.productId = this.activatedRoute.snapshot.paramMap.get('id');
        this.getProductById(this.productId);
        this.getAllCartProducts();

    }

    calculateTotal(){
        this.grandTotal = 0;
        for(let product of this.productArray){
            this.grandTotal += (product.price-product.price*product.discount/100);
            this.grandTotal = Math.floor(this.grandTotal);           
        }

    }

    // getAllCartProducts(){
    //     this.api.getAllCartProducts().subscribe(
    //         response => {
    //             this.productArray = response;
    //             this.calculateTotal();
    //         }
    //     )
    // }

    getAllCartProducts(){
        this.productArray = this.api.getAllCartProducts();
        this.calculateTotal();
    }

    getProductById(id: number) {
        this.api.getProductById(id).subscribe(
            response => {
                this.api.saveProductToCart(response);
                this.getAllCartProducts();
            }
        )
    }

    removeItemFromCart(productId: any){
        this.api.deleteFromCart(productId);
        this.calculateTotal();
    }
    // removeItemFromCart(productId: any){

    //     this.api.deleteCartItem(productId).subscribe(
    //         response => {
    //             console.log("del suc");
    //             this.getAllCartProducts();
    //         }
    //     )
    // }


}
