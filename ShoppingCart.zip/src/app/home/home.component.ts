import { Component } from '@angular/core';
import { Product } from '../model/product';
import { ApiService } from '../services/api.service';
import { Router } from '@angular/router'

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent {

    productArray: any;

    constructor(private api: ApiService, private router:Router) {

    }

    ngOnInit() {
        this.getAllProducts();
    }

    fetchProduct(product: any) {
        this.router.navigate(["/product", product.id, product.name, product.brand, product.model, product.price, product.madeIn, product.discount, product.color, product.image])
    }

    getAllProducts() {
        this.api.getAllProducts().subscribe(
            response => {
                this.productArray = response;
            }
        )

    }
}
