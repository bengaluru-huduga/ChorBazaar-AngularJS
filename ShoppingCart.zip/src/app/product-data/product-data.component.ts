import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router'
import { Product } from '../model/product';
import { Router } from '@angular/router'
import { ApiService } from '../services/api.service';

@Component({
    selector: 'app-product-data',
    templateUrl: './product-data.component.html',
    styleUrls: ['./product-data.component.css']
})
export class ProductDataComponent {

    productArray: any = [];
    productObj: any;
    productId: any;
    productName: any;
    productBrand: any;
    productModel: any;
    productPrice: any;
    productMadeIn: any;
    productDiscount: any;
    productColor: any;
    productImage: any;
    discountAvailable !: boolean;
    finalPrice !: number;

    constructor(private activatedRoute: ActivatedRoute, private router:Router, private api:ApiService){

    }

    ngOnInit(){
        // this.productObj = new Product();
        this.productId = this.activatedRoute.snapshot.paramMap.get('id');
        // this.productObj.id = this.productId;
        this.productName = this.activatedRoute.snapshot.paramMap.get('name');
        this.productBrand = this.activatedRoute.snapshot.paramMap.get('brand');
        this.productModel = this.activatedRoute.snapshot.paramMap.get('model');
        this.productPrice = this.activatedRoute.snapshot.paramMap.get('price');
        this.productMadeIn = this.activatedRoute.snapshot.paramMap.get('madeIn');
        this.productDiscount = this.activatedRoute.snapshot.paramMap.get('discount');
        this.productColor = this.activatedRoute.snapshot.paramMap.get('color');
        this.productImage = this.activatedRoute.snapshot.paramMap.get('image');
        this.finalPrice = this.productPrice-this.productPrice*this.productDiscount/100
        if(this.productDiscount==0)
            this.discountAvailable = false;
        else{
            this.discountAvailable = true;
        }
    }

    buyNow(id: any){
        // this.getProductById(id);
        this.router.navigate(['/cart', id]);
    }

    returnToHome(){
        this.router.navigate(['/home']);
    }

    
    // getProductById(id: number) {
    //     this.api.getProductById(id).subscribe(
    //         response => {
    //             this.api.saveProductToCart(response).subscribe();
                
                    
    //         }
    //     )
    // }

    

}
